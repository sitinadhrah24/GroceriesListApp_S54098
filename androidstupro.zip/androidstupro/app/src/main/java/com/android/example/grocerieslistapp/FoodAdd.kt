package com.android.example.grocerieslistapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class FoodAdd : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_add)

        val btnSave =  findViewById<ImageButton>(R.id.btnSave)
        btnSave.setOnClickListener(){
            val entiti = findViewById<EditText>(R.id.inEntiti)
            val detail = findViewById<EditText>(R.id.inDetail)


            val emptyLevel = emptiness(entiti, detail)
            if (emptyLevel>0){
                //which field is empty
                when(emptyLevel){
                    5 -> subToast("entiti must not empty!")
                    6 -> subToast("detail must not empty!")
                    11 -> subToast("entiti and detail must not empty")

                }
            }else{
                //check for exists entity
                val status = checkKey(entiti.text.toString())
                val ent = entiti.text.toString()
                val det = detail.text.toString()

                if(!status){
                    val db = openOrCreateDatabase("barang", MODE_PRIVATE,null)
                    val sql = "INSERT INTO makanan (entiti, detail) VALUES ('$ent','$det');"
                    db.execSQL(sql)
                    subToast("new entiti $ent added!")
                    val intent = Intent(this, FoodList::class.java).apply {

                    }
                    startActivity(intent)
                }else{
                    subToast("entiti already exists inside database!")
                }
            }

        }

    }

    private fun checkKey(entiti: String):Boolean{
        val db = openOrCreateDatabase("barang", MODE_PRIVATE,null)
        val sql = "select * from makanan where entiti='$entiti'"
        val cursor = db.rawQuery(sql, null)
        var out=false
        if(cursor.count>0)
            out=true
        return out
    }
    private fun emptiness(entiti: EditText, detail: EditText):Int{
        var empty = 0

        if(entiti.text.isEmpty())
            empty+=5

        if(detail.text.isEmpty())
            empty+=6

        return empty

    }
    private fun subToast(msg: String){
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show()

    }
}