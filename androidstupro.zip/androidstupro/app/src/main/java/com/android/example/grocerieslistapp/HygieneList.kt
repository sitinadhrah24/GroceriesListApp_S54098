package com.android.example.grocerieslistapp

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class HygieneList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hygiene_list)

        val actionBar = supportActionBar
        actionBar!!.title = "Personal Care and Hygiene List"
        actionBar.setDisplayHomeAsUpEnabled(true)


        var entities = ArrayList<String>()
        if (!dbExists(this, "hygiene")){
            createDB();
        }
        val db: SQLiteDatabase = openOrCreateDatabase("hygiene", MODE_PRIVATE,null)
        val sql = "SELECT entiti from toiletries"
        val c: Cursor = db.rawQuery(sql, null)
        while(c.moveToNext()){
            val entiti = c.getString(0)
            entities.add(entiti)
        }
        c.close()

        val myAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,entities)
        val lv = findViewById<ListView>(R.id.lv)
        lv.setAdapter(myAdapter)
        lv.onItemClickListener = AdapterView.OnItemClickListener{ adapter, v, position, arg3 ->
            val value = adapter.getItemAtPosition(position).toString()
            val intent = Intent(this, HygieneView::class.java).apply {
                putExtra("entiti", value.toString())
            }
            startActivity(intent)
        }


        val fab = findViewById<FloatingActionButton>(R.id.fab1)
        fab.setOnClickListener(){
            val intent = Intent(this, HygieneAdd::class.java).apply {

            }
            startActivity(intent)
        }
    }

    private fun dbExists(c: Context, dbName: String):Boolean{
        val dbFile: File = c.getDatabasePath(dbName)
        return dbFile.exists()
    }

    private fun createDB(){
        val db = openOrCreateDatabase("hygiene", MODE_PRIVATE, null)
        subToast("Database hygiene created!")
        val sqlText = "CREATE TABLE IF NOT EXISTS toiletries" +
                "(entiti VARCHAR(50) PRIMARY KEY," +
                "detail VARCHAR(50) NOT NULL" +
                ");"

        subToast("Table toiletries created")
        db.execSQL(sqlText)
        var nextSQL = "INSERT INTO toiletries( entiti,detail) VALUES ('gigi','berus gigi');"
        db.execSQL(nextSQL)
        nextSQL = "INSERT INTO toiletries( entiti,detail) VALUES ('badan','sabun detol');"
        db.execSQL(nextSQL)
        nextSQL = "INSERT INTO toiletries( entiti,detail) VALUES ('rambut','head n shoulders');"
        db.execSQL(nextSQL)
        subToast("3 sample entities added")

    }
    private fun subToast(msg: String){
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show()

    }
}